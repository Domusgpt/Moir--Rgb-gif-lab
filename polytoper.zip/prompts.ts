/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export const promptSuggestions: {emoji: string, prompt: string}[] = [];

export const buildCreativeInstruction = (
  originalImage: string | null, 
  frameCount: number
): string => {
  const storyPrompt = `Animate the provided image. The animation should be a clean, seamless loop inspired by polytopal rotation.
- Identify the main subject of the image.
- Animate the main subject with a 3D flipping or rotating effect on its Y-axis.
- The background can have a subtle complementary motion, like a slow spin or zoom.
- The movements should be synchronized and create a mesmerizing, geometric effect.
- Maintain the original color palette of the image.
- The entire animation must stay within the frame.`;
  
  const baseInstruction = `Create a short, ${frameCount}-frame animation based on the creative direction. The movement should be smooth, and the final frame must loop perfectly back to the first.`;
  const styleConsistencyInstruction = `It is crucial that all ${frameCount} frames are in the same, consistent artistic style, matching the provided source image.`;
  const identityLockInstruction = `Maintain the subject's integrity and core shapes consistently across all frames. The subject should be clearly recognizable from one frame to the next.`;
  
  const frameDurationInstruction = `
Based on the creative direction, determine the optimal frame duration for the animation. A duration around 100-150ms is likely appropriate for this smooth rotation.
`;

  let creativeDirection = `
CREATIVE DIRECTION:
${storyPrompt}
${baseInstruction}
${styleConsistencyInstruction}
${identityLockInstruction}`;
  
  return `
${creativeDirection}
${frameDurationInstruction}

REQUIRED RESPONSE FORMAT:
Your response MUST contain two parts:
1. A valid JSON object containing a single key: "frameDuration". The value must be a number representing the milliseconds per frame (between 80 and 2000, per instructions above). Do not wrap the JSON in markdown backticks.
2. The ${frameCount}-frame sprite sheet image.

Example of the JSON part:
{"frameDuration": 120}
`;
};
